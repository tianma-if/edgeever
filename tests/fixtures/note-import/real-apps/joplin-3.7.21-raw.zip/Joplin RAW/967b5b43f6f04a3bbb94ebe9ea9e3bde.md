原样保留.zip

id: 967b5b43f6f04a3bbb94ebe9ea9e3bde
mime: application/zip
filename: 
created_time: 2026-10-28T17:16:22.157Z
updated_time: 2026-10-28T17:16:22.157Z
user_created_time: 2026-10-28T17:16:22.157Z
user_updated_time: 2026-10-28T17:16:22.157Z
file_extension: zip
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 196
is_shared: 0
share_id: 
master_key_id: 
user_data: 
blob_updated_time: 1793207782157
ocr_text: 
ocr_details: 
ocr_status: 0
ocr_error: 
ocr_driver_id: 1
is_locked: 0
type_: 4