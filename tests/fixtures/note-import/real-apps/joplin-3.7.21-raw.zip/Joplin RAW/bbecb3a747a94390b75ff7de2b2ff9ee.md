id: bbecb3a747a94390b75ff7de2b2ff9ee
note_id: ee29197eeac04a3e912a606265323b1a
tag_id: d803b1edfbce491e955626fa75e0ae48
created_time: 2026-10-28T17:16:22.760Z
updated_time: 2026-10-28T17:16:22.760Z
user_created_time: 2026-10-28T17:16:22.760Z
user_updated_time: 2026-10-28T17:16:22.760Z
encryption_cipher_text: 
encryption_applied: 0
is_shared: 0
type_: 6