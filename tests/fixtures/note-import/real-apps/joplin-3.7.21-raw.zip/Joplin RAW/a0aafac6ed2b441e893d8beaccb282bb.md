tag18

id: a0aafac6ed2b441e893d8beaccb282bb
created_time: 2026-10-28T17:16:22.516Z
updated_time: 2026-10-28T17:16:22.516Z
user_created_time: 2026-10-28T17:16:22.516Z
user_updated_time: 2026-10-28T17:16:22.516Z
encryption_cipher_text: 
encryption_applied: 0
is_shared: 0
parent_id: 
user_data: 
type_: 5